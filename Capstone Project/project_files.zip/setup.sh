#!/bin/bash

echo "Setting up your environment ..."

echo "Removing AWS cli 1.16.17 ..."
pip uninstall awscli -y

echo "Upgrading PyYAML, Markdown, Mako, Docutils ..."
pip install --quiet --ignore-installed PyYAML markdown mako docutils

echo "Installing Apache Airflow ..."
sudo apt-get update
sudo apt-get install build-essential -y

AIRFLOW_VERSION=1.10.14
PYTHON_VERSION="$(python --version | cut -d " " -f 2 | cut -d "." -f 1-2)"
CONSTRAINT_URL="https://raw.githubusercontent.com/apache/airflow/constraints-${AIRFLOW_VERSION}/constraints-${PYTHON_VERSION}.txt"
pip install --quiet "apache-airflow==${AIRFLOW_VERSION}" --constraint "${CONSTRAINT_URL}"

airflow db init
airflow scheduler --daemon
airflow webserver --daemon --port 3000



echo "Installing AWS CLI ..."
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
rm -rf aws awscliv2.zip

## For configuring AWS
echo "Configuring AWS CLI ..."
mkdir -p ~/.aws
cd ~/.aws/

touch config
touch credentials

echo -e "[default]\nregion = us-west-2\noutput = table" > ~/.aws/config
echo -e "[default]\naws_access_key_id = AKIAY3KLFRX2UYH3OOMD\naws_secret_access_key = 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" > ~/.aws/credentials


## For loading custom AWS commands on startup
chmod 777 /home/workspace/aws_scripts/emr/list_clusters.sh
chmod 777 /home/workspace/aws_scripts/emr/describe_cluster.sh
chmod 777 /home/workspace/aws_scripts/emr/launch.sh
chmod 777 /home/workspace/aws_scripts/emr/terminate.sh

chmod 777 /home/workspace/aws_scripts/redshift/list_clusters.sh
chmod 777 /home/workspace/aws_scripts/redshift/launch.sh
chmod 777 /home/workspace/aws_scripts/redshift/terminate.sh

cp /home/workspace/utils/bashrc.backup ~/.bashrc
echo "Done."


exec bash