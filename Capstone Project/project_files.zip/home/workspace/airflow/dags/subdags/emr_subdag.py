from airflow import DAG
from airflow.models import Variable
from airflow.contrib.operators.emr_add_steps_operator import EmrAddStepsOperator
from airflow.contrib.sensors.emr_step_sensor import EmrStepSensor

from helpers.emr.config_vars import SPARK_STEPS


def get_emr_subdag(parent_dag_name, child_dag_name,
                   job_flow_id, table, aws_conn_id,
                   **kwargs):
    """ 
        Factory function that returns a DAG which 
        processes a table in S3 using Spark on EMR
    """
    
    dag = DAG(f'{parent_dag_name}.{child_dag_name}', **kwargs)
    
    # Get Variables
    RAW_DATA_BUCKET = Variable.get('RAW_DATA_BUCKET')
    STAGING_DATA_BUCKET = Variable.get('STAGING_DATA_BUCKET')
    SPARK_SCRIPTS_BUCKET = Variable.get('SPARK_SCRIPTS_BUCKET')
    
    # Add steps to the EMR cluster
    generate_dim = EmrAddStepsOperator(
        task_id=f'generate_{table}_steps',
        job_flow_id=job_flow_id,
        aws_conn_id=aws_conn_id,
        steps=SPARK_STEPS,
        params={# `params` will be used by SPARK_STEPS
            "NAME": f'Generating {table.title()} Table',
            "SPARK_SCRIPT": SPARK_SCRIPTS_BUCKET + f'/{table}.py',
            "RAW_DATA_BUCKET": RAW_DATA_BUCKET,
            "STAGING_DATA_BUCKET": STAGING_DATA_BUCKET
        },
        dag=dag,
    )

    # wait for the steps to complete
    final_step = len(SPARK_STEPS) - 1 # this value will let the sensor know the last step to watch
    generate_dim_sensor = EmrStepSensor(
        task_id=f'generate_{table}_sensor',
        job_flow_id=job_flow_id,
        step_id="{{ task_instance.xcom_pull(task_ids='generate_" + table + "_steps', key='return_value')[" +  str(final_step) + "] }}",
        aws_conn_id=aws_conn_id,
        dag=dag,
    )
    
    generate_dim >> generate_dim_sensor
    
    return dag