from airflow.utils.dates import days_ago
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.subdag_operator import SubDagOperator

from airflow.contrib.operators.emr_create_job_flow_operator import EmrCreateJobFlowOperator
from airflow.contrib.operators.emr_terminate_job_flow_operator import EmrTerminateJobFlowOperator

from helpers.emr.config_vars import JOB_FLOW_OVERRIDES
from subdags.emr_subdag import get_emr_subdag


default_args = {
    "owner": "airflow",
    'start_date': days_ago(2)
}

DAG_NAME = 'olist_data_pipeline'
dag = DAG(
    DAG_NAME,
    default_args=default_args,
    schedule_interval="@once",
    max_active_runs=1
)


START = DummyOperator(task_id="START", dag=dag)


# Create an EMR cluster
cluster_launch_task_id = 'launch_emr_cluster'
launch_emr_cluster = EmrCreateJobFlowOperator(
    task_id=cluster_launch_task_id,
    job_flow_overrides=JOB_FLOW_OVERRIDES,
    aws_conn_id="aws_default",
    emr_conn_id="emr_default",
    dag=dag,
)


tables = ['customer', 'seller', 'product', 'calender', 'order_item']
subdag_dict = dict()

for table in tables:
    curr_task_name = f'generate_{table}_dim'
    subdag_dict[curr_task_name] = SubDagOperator(
        task_id=curr_task_name,
        subdag=get_emr_subdag(
            parent_dag_name=DAG_NAME,
            child_dag_name=curr_task_name,
            table=table,
            job_flow_id="{{ task_instance.xcom_pull(task_ids='" + cluster_launch_task_id + "', dag_id='" + DAG_NAME + "' , key='return_value') }}",
            aws_conn_id='aws_default',
            start_date=default_args['start_date']
        ),
        dag=dag,
    )


# # Terminate the EMR cluster
terminate_emr_cluster = EmrTerminateJobFlowOperator(
    task_id="terminate_emr_cluster",
    job_flow_id="{{ task_instance.xcom_pull(task_ids='" + cluster_launch_task_id + "', dag_id='" + DAG_NAME + "' , key='return_value') }}",
    aws_conn_id="aws_default",
    trigger_rule="all_done",
    dag=dag,
)

END = DummyOperator(task_id="END", dag=dag)


START >> launch_emr_cluster

for table in tables:
    launch_emr_cluster >> subdag_dict[f'generate_{table}_dim'] >> terminate_emr_cluster

terminate_emr_cluster >> END