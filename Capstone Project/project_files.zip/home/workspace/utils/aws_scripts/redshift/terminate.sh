#!/bin/bash

if [ -z "$1" ]
then
    echo "No cluster identifier specified."
    aws redshift delete-cluster --help
else
    aws redshift delete-cluster \
        --cluster-identifier $1 \
        --skip-final-cluster-snapshot
fi