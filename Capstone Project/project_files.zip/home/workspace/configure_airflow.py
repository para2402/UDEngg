import os
from configparser import ConfigParser


PROJECT_BASE = os.environ['PROJECT_BASE']
PROJECT_CONFIG_PATH = PROJECT_BASE + '/config.cfg'

AIRFLOW_CONFIG_PATH = '/root/airflow/airflow.cfg'


def modify_config():
    config = ConfigParser()
    config.read(AIRFLOW_CONFIG_PATH)

    config['core']['dags_folder'] = PROJECT_BASE + '/airflow/dags'
    config['core']['load_examples'] = 'False'
    config['core']['plugins_folder'] = PROJECT_BASE + '/airflow/plugins'
    config['core']['sql_alchemy_conn'] = 'postgresql+psycopg2://airflow:airflow@localhost:5432/airflow'
    config['core']['executor'] = 'LocalExecutor'

    config['webserver']['expose_config'] = 'True'
    config['webserver']['reload_on_plugin_change'] = 'True'

    with open(AIRFLOW_CONFIG_PATH, 'w') as fp:
        config.write(fp)

    os.system('airflow db init')


def set_variables():
    config = ConfigParser()
    config.read(PROJECT_CONFIG_PATH)
    
    ROOT_BUCKET = config['S3']['ROOT_BUCKET']
    RAW_DATA_KEY = config['S3']['RAW_DATA_KEY']
    STAGING_DATA_KEY = config['S3']['STAGING_DATA_KEY']
    SPARK_SCRIPTS_KEY = config['S3']['SPARK_SCRIPTS_KEY']
    os.system(f'airflow variables set ROOT_BUCKET {ROOT_BUCKET}')
    os.system(f'airflow variables set RAW_DATA_KEY {RAW_DATA_KEY}')
    os.system(f'airflow variables set STAGING_DATA_KEY {STAGING_DATA_KEY}')
    os.system(f'airflow variables set SPARK_SCRIPTS_KEY {SPARK_SCRIPTS_KEY}')


def set_connections():
    config = ConfigParser()
    config.read(PROJECT_CONFIG_PATH)
    
    conn_id = 'redshift_connection'
    conn_type = 'postgres'
    description = 'Olist Redshift Analytics Warehouse'
    
    HOST = config['REDSHIFT']['HOST']
    DB_NAME = config['REDSHIFT']['DB_NAME']
    DB_USERNAME = config['REDSHIFT']['DB_USERNAME']
    DB_PASSWORD = config['REDSHIFT']['DB_PASSWORD']
    DB_PORT = config['REDSHIFT']['DB_PORT'] if config['REDSHIFT']['DB_PORT'] else 5439
    
    os.system(f"""airflow connections add --conn-type '{conn_type}' \
                                          --conn-description '{description}' \
                                          --conn-host '{HOST}' \
                                          --conn-schema '{DB_NAME}' \
                                          --conn-login '{DB_USERNAME}' \
                                          --conn-password '{DB_PASSWORD}' \
                                          --conn-port {DB_PORT} \
                                          {conn_id}""")


if __name__ == '__main__':
    modify_config()
    set_variables()
    set_connections()